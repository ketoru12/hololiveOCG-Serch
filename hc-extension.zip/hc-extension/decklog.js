(async function() {
  const _api = typeof browser !== 'undefined' ? browser : chrome;
  const delay = ms => new Promise(r => setTimeout(r, ms));

  // storageからデッキデータを取得
  let deckData = null;
  for (let i = 0; i < 10; i++) {
    const result = await _api.storage.local.get('hc_pending');
    if (result.hc_pending) {
      deckData = result.hc_pending;
      await _api.storage.local.remove('hc_pending');
      break;
    }
    await delay(500);
  }
  if (!deckData) return;

  // scriptタグをDOMに注入してMAIN worldで実行（Chrome/Firefox両対応）
  const execCode = "async function execDecklog(deckData) {\n  const delay = ms => new Promise(r => setTimeout(r, ms));\n\n  let stdInp = null;\n  for (let i = 0; i < 60; i++) {\n    stdInp = document.querySelector('input[type=\"radio\"][name=\"regulation\"][value=\"S\"]');\n    if (stdInp) break;\n    await delay(500);\n  }\n  if (!stdInp) { alert('\u30b9\u30bf\u30f3\u30c0\u30fc\u30c9\u304c\u898b\u3064\u304b\u308a\u307e\u305b\u3093'); return; }\n  stdInp.click();\n  await delay(1200);\n\n  let ready = false;\n  for (let w = 0; w < 30; w++) {\n    if (document.querySelector('.card-searchform') ||\n        document.querySelectorAll('input[type=radio]').length > 3) {\n      ready = true; break;\n    }\n    await delay(500);\n  }\n  if (!ready) { alert('\u30ab\u30fc\u30c9\u9078\u629e\u753b\u9762\u30bf\u30a4\u30e0\u30a2\u30a6\u30c8'); return; }\n\n  const selType = async label => {\n    const inp = Array.from(document.querySelectorAll('input[type=radio]')).find(r => {\n      const lbl = r.closest('label') || document.querySelector('label[for=\"'+r.id+'\"]');\n      return lbl && lbl.textContent.trim().indexOf(label) > -1;\n    });\n    if (inp) { inp.click(); await delay(700); return true; }\n    return false;\n  };\n\n  const tryAdd = async (no, cnt) => {\n    const t = Array.from(document.querySelectorAll('button,span')).find(b => {\n      const tx = b.textContent.trim(); return tx === '\u30ab\u30fc\u30c9\u756a\u53f7' || tx === 'No.';\n    });\n    if (t) { t.click(); await delay(400); }\n    const inp = Array.from(document.querySelectorAll('input')).find(i => {\n      const p = i.placeholder || ''; return p.indexOf('\u756a\u53f7') > -1 || p.indexOf('\u30ad\u30fc\u30ef\u30fc\u30c9') > -1;\n    });\n    if (!inp) return false;\n    inp.focus();\n    Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set.call(inp, no);\n    ['input', 'change', 'keyup'].forEach(ev => inp.dispatchEvent(new Event(ev, { bubbles: true })));\n    await delay(1500);\n    const el = document.querySelector('.card-item'); if (!el) return false;\n    const inc = el.querySelector('.card-inc'); if (!inc) return false;\n    for (let i = 0; i < cnt; i++) { inc.click(); await delay(350); }\n    return true;\n  };\n\n  let ok = 0, ng = [];\n  const { oshi, main, yell } = deckData;\n  if (oshi) {\n    await selType('\u63a8\u3057\u30db\u30ed\u30e1\u30f3');\n    if (await tryAdd(oshi.id, 1)) ok++; else ng.push(oshi.id + '(\u63a8\u3057)');\n    await delay(400);\n  }\n  if (yell && yell.length) {\n    await selType('\u30a8\u30fc\u30eb\u30c7\u30c3\u30ad');\n    for (const c of yell) {\n      if (!c.id) continue;\n      if (await tryAdd(c.id, c.count)) ok++; else ng.push(c.id);\n      await delay(300);\n    }\n  }\n  if (main && main.length) {\n    await selType('\u30e1\u30a4\u30f3\u30c7\u30c3\u30ad');\n    for (const c of main) {\n      if (!c.id) continue;\n      if (await tryAdd(c.id, c.count)) ok++; else ng.push(c.id);\n      await delay(300);\n    }\n  }\n  alert('\u5b8c\u4e86: ' + ok + '\u4ef6\u6210\u529f' + (ng.length ? '\\\\n\u5931\u6557: ' + ng.join(', ') : ''));\n}\n";
  const script = document.createElement('script');
  script.textContent = '(function() + execCode + )();';
  document.documentElement.appendChild(script);
  script.remove();

  await delay(200);
  window.postMessage({ type: 'HC_EXEC', data: deckData }, '*');
})();
