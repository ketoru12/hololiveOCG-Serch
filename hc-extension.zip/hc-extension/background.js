const _api = typeof browser !== 'undefined' ? browser : chrome;

_api.runtime.onInstalled.addListener(() => {
  console.log('ホロカ→DECKLOG インストール完了');
});
